// vite.config.js
import { defineConfig } from "vite";
import { resolve } from "path";
import { VitePWA } from "vite-plugin-pwa"; // <-- 1. IMPORT PLUGIN

export default defineConfig({
  // Pengaturan 'base' Anda. Ini penting!
  base: "/starter-project-with-vite/",

  // Pengaturan 'root' kustom Anda
  root: resolve(__dirname, "src"),

  // Pengaturan 'publicDir' kustom Anda
  publicDir: resolve(__dirname, "src", "public"),

  plugins: [
    // 2. TAMBAHKAN PLUGIN PWA DI SINI
    VitePWA({
      // Beri tahu plugin untuk mengikuti 'base' config Anda
      base: "/starter-project-with-vite/",

      // Beri tahu plugin di mana file SW kustom Anda berada
      // (Saya berasumsi sw.js Anda ada di 'src/sw.js' berdasarkan chat kita)
      // 'src' adalah root, jadi kita cari 'sw.js' di dalamnya.
      srcDir: ".",
      filename: "sw.js", // Nama file SW Anda di dalam 'src'
      strategy: "injectManifest", // Kita pakai 'sw.js' kustom Anda

      // Konfigurasi manifest
      manifest: {
        name: "StoryMap",
        short_name: "StoryMap",
        // URL harus relatif terhadap root, plugin akan menambahkan 'base'
        start_url: "/",
        display: "standalone",
        theme_color: "#ffffff",
        icons: [
          {
            // Path ini harus ada di 'src/public/icons/icon-192.svg'
            src: "/icons/icon-192.svg",
            sizes: "192x192",
            type: "image/svg+xml",
          },
          {
            src: "/icons/icon-512.svg", // Harus ada di 'src/public/icons/icon-512.svg'
            sizes: "512x512",
            type: "image/svg+xml",
          },
        ],
      },

      // Aktifkan PWA di mode development untuk testing
      devOptions: {
        enabled: true,
      },
    }),
  ],

  // Sisa config Anda
  build: {
    outDir: resolve(__dirname, "dist"),
    emptyOutDir: true,
  },
  resolve: {
    alias: {
      "@": resolve(__dirname, "src"),
    },
  },
});
