import routes from "../routes/routes";
import { getActiveRoute } from "../routes/url-parser";

class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;

    this.#setupDrawer();
  }

  #setupDrawer() {
    // ... (Semua kode #setupDrawer() Anda sudah benar, tidak perlu diubah) ...
    if (this.#drawerButton && this.#navigationDrawer) {
      this.#drawerButton.setAttribute(
        "aria-controls",
        this.#navigationDrawer.id || "navigation-drawer"
      );
      this.#drawerButton.setAttribute("aria-expanded", "false");

      const toggleDrawer = () => {
        const isOpen = this.#navigationDrawer.classList.toggle("open");
        this.#drawerButton.setAttribute("aria-expanded", String(isOpen));
      };

      this.#drawerButton.addEventListener("click", toggleDrawer);
      this.#drawerButton.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          toggleDrawer();
        }
      });

      document.body.addEventListener("click", (event) => {
        if (
          !this.#navigationDrawer.contains(event.target) &&
          !this.#drawerButton.contains(event.target)
        ) {
          this.#navigationDrawer.classList.remove("open");
        }

        this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
          if (link.contains(event.target)) {
            this.#navigationDrawer.classList.remove("open");
          }
        });
      });
    }
  }

  async renderPage() {
    if (!this.#content) return;

    const oldCameraStream = document.querySelector("video");
    if (oldCameraStream && oldCameraStream.srcObject) {
      oldCameraStream.srcObject.getTracks().forEach((track) => track.stop());
      oldCameraStream.srcObject = null;
    }

    const url = getActiveRoute();
    const page = routes[url];

    const newPage = document.createElement("div");
    // PERBAIKAN 1: Hapus 'page-enter' dari sini agar tidak konflik
    newPage.className = "page";
    newPage.innerHTML = await page.render(); // ... (Logika penambahan H1 Anda sudah benar) ...

    const hasH1 = !!newPage.querySelector("h1");
    if (!hasH1) {
      const url = window.location.hash.replace("#", "") || "/";
      const titleMap = {
        "/": "Map",
        "/map": "Map",
        "/add": "Add Story",
        "/saved": "Saved Stories",
        "/login": "Login",
        "/register": "Register",
        "/profile": "Profile",
      };
      const h1 = document.createElement("h1");
      h1.textContent = titleMap[url] || "Page";
      const firstSection = newPage.querySelector("section") || newPage;
      firstSection.insertBefore(h1, firstSection.firstChild);
    }

    const oldPage = this.#content.querySelector(".page");

    // PERBAIKAN 2: Pisahkan logika transisi
    const doSwap = (useCssFallback = false) => {
      const TRANSITION_DURATION = 350;

      if (useCssFallback) {
        // Ini adalah logika fallback CSS Anda yang lama
        newPage.classList.add("page-enter");
        this.#content.appendChild(newPage);
        // eslint-disable-next-line no-unused-expressions
        newPage.getBoundingClientRect();
        newPage.classList.add("page-enter-active");

        if (oldPage) {
          oldPage.classList.add("page-exit");
          setTimeout(() => {
            if (oldPage.parentElement) oldPage.remove();
          }, TRANSITION_DURATION);
        }
        return TRANSITION_DURATION;
      } else {
        // Ini adalah logika HANYA TUKAR DOM untuk startViewTransition
        if (oldPage) oldPage.remove();
        this.#content.appendChild(newPage);
        return 0;
      }
    }; // Gunakan startViewTransition

    try {
      if (typeof document.startViewTransition === "function") {
        await document.startViewTransition(() => {
          doSwap(false); // Panggil doSwap TANPA animasi CSS
        });
      } else {
        const d = doSwap(true); // Panggil doSwap DENGAN animasi CSS
        await new Promise((r) => setTimeout(r, d));
      }
    } catch (err) {
      // Fallback jika transisi error
      const d = doSwap(true);
      await new Promise((r) => setTimeout(r, d));
    }

    // PERBAIKAN 3 (YANG PALING PENTING):
    // Kirim elemen 'newPage' ke 'afterRender' untuk memperbaiki TypeError
    await page.afterRender(newPage);
  }
}

export default App;
