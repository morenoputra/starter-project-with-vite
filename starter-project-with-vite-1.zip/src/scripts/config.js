const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  VAPID_PUBLIC_KEY: 'BOSnAf_MsqMRlkQsXPliiAXLd7JtH13-YbDA-2n9ZTacYtkQ01HtTAjFl7r_9BSBhVn3UB47cSdlkrCbHiaZtAM',
  VAPID_ENDPOINT: null,
  SUBSCRIBE_ENDPOINT: null 
};

export default CONFIG;